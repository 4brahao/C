#include <stdio.h>

int comprar_itens (){
    int limite_itens = 3;
    return limite_itens;
}

int main ()
{
    printf ("Exercicio 2:\n");
    printf ("Itens comprados %d\n", comprar_itens());
    
    return 0;
}