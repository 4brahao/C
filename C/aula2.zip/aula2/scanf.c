#include <stdio.h>

int main() {
    int idade;
    printf ("Digite sua idade");
    scanf ("%d", &idade);
    printf ("Você tem %d anos. \n", idade);
    
    return 0;
}