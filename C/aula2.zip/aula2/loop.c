#include <stdio.h>

int i = 1;

while (i <= 10) {
    printf ("%d\n", i);
    i++
}