#include <stdio.h>

int main (){
    int nmb1= 2;
    int nmb2= 1;
    
    int soma= nmb1 + nmb2;
    int subtracao= nmb1 - nmb2;
    int divisao= nmb1 / nmb2;
    int multiplicacao= nmb1 * nmb2;
    
    printf("soma:%d\n",soma);
    printf("subtracao:%d\n",subtracao);
    printf("divisao:%d\n",divisao);
    printf("multiplicacao:%d\n",multiplicacao);
    
    return 0;
}